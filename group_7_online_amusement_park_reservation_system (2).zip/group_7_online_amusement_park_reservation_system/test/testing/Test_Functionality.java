package testing;

import group_7_online_amusement_park_reservation_system.Admin;
import group_7_online_amusement_park_reservation_system.Child;
import group_7_online_amusement_park_reservation_system.Customer;
import group_7_online_amusement_park_reservation_system.Payment;
import group_7_online_amusement_park_reservation_system.PaymentComponent;
import group_7_online_amusement_park_reservation_system.DiscountDecorator;
import java.sql.SQLException;
import org.junit.*;
import static org.junit.Assert.*;

public class Test_Functionality {

    @BeforeClass
    public static void setUpClass() {
        System.out.println("Testing is running for Admin, Customer, and Payment methods");
    }

    @AfterClass
    public static void tearDownClass() {
        System.out.println("Testing is done for Admin, Customer, and Payment methods");
    }

    @Before
    public void setUp() {
        System.out.println("Setting up before test");
    }

    @After
    public void tearDown() {
        System.out.println("Cleaning up after test");
    }

    @Test
    public void testAdminSignup() throws SQLException {
        System.out.println("Testing Admin.saveToDatabase method");
        Admin admin = new Admin(200, "Alice", "Manager", "Ops", "Senior", "pass123".toCharArray());
        int rows = admin.saveAdminToDatabase();
        assertTrue("Admin should be inserted", rows > 0);
    }

    @Test
    public void testCustomerLogin() throws SQLException {
        boolean loggedIn = Customer.login("bob123", "pwd");
        assertTrue("Customer should login successfully", loggedIn);
    }

    @Test
    public void testPaymentSave() throws SQLException {
        System.out.println("Testing Payment.saveToDatabase with decorator");
        Payment basePayment = new Payment(500, "card", 12345678, 123, "12/25", 1000, 372371337);
        PaymentComponent decorated = new DiscountDecorator(basePayment, 100);
        basePayment.saveToDatabase(decorated);
        assertTrue(true);
    }
} 
