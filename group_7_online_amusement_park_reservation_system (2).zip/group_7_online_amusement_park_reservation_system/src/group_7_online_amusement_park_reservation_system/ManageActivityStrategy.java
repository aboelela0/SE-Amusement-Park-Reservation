// Interface: ManageActivityStrategy
package group_7_online_amusement_park_reservation_system;

public interface ManageActivityStrategy {
    void execute(int activityID);
}
